#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future

MODDIR=${0%/*}
# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Wait for boot to be completed
while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done
# Apply settings
sleep 20

# GPU Tuning
settings put global GPUTUNER_SWITCH true


# better idling
echo 0-3 > /dev/cpuset/restricted/cpus

# cpusets tuning
echo 100 > /sys/module/cpu_input_boost/parameters/input_boost_duration
echo 2-3 > /dev/cpuset/audio-app/cpus
echo 0-1 > /dev/cpuset/background/cpus
echo 0-3 > /dev/cpuset/system-background/cpus
echo 0-3,4-7 > /dev/cpuset/foreground/cpus
echo 0-3,7-7 > /dev/cpuset/foreground/boost/cpus
echo 0-3,7-7 > /dev/cpuset/foreground/cpus
echo 0-7 > /dev/cpuset/top-app/cpus
echo 0-7 > /dev/cpuset/game/cpus
echo 0-7 > /dev/cpuset/gamelite/cpus

# cpusets & Stune boost
echo 1 > /dev/stune/top-app/schedtune.colocate
echo 1 > /dev/stune/top-app/schedtune.sched_boost_enabled
echo 1 > /dev/stune/top-app/schedtune.sched_boost_no_override
echo 0 > /dev/stune/top-app/schedtune.prefer_idle
echo 0 > /dev/stune/top-app/schedtune.boost
echo 0 > /dev/stune/foreground/schedtune.colocate
echo 1 > /dev/stune/foreground/schedtune.sched_boost_enabled
echo 1 > /dev/stune/foreground/schedtune.sched_boost_no_override
echo 0 > /dev/stune/foreground/schedtune.prefer_idle
echo 0 > /dev/stune/foreground/schedtune.boost
echo 0 > /dev/stune/background/schedtune.colocate
echo 1 > /dev/stune/background/schedtune.sched_boost_enabled
echo 0 > /dev/stune/background/schedtune.sched_boost_no_override
echo 0 > /dev/stune/background/schedtune.prefer_idle
echo 0 > /dev/stune/background/schedtune.boost
echo 0 > /dev/stune/schedtune.colocate
echo 1 > /dev/stune/schedtune.sched_boost_enabled
echo 0 > /dev/stune/schedtune.sched_boost_no_override
echo 0 > /dev/stune/schedtune.prefer_idle
echo 0 > /dev/stune/schedtune.boost

# Power Saving
chmod 664 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "freeze mem" > /sys/power/state
echo "s2idle [deep]" > /sys/power/mem_sleep
